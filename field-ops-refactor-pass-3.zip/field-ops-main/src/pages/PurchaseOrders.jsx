import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Plus, Receipt, Buildings, CalendarBlank, CaretRight,
  MagnifyingGlass, X, CheckCircle, Clock, PaperPlaneTilt,
  Package, Warning } from '@phosphor-icons/react'
import { db } from '../lib/supabase.js'

const STATUS_META = {
  draft:        { label: 'Draft',        color: 'var(--grey-base)', bg: 'var(--grey-tint-80)', icon: Clock },
  queued:       { label: 'Queued',       color: 'var(--purple-tint-20)', bg: 'var(--purple-soft)', icon: Clock },
  running:      { label: 'Running',      color: 'var(--warning)', bg: 'var(--warning-soft)', icon: PaperPlaneTilt },
  submitted:    { label: 'Submitted',    color: 'var(--warning)', bg: 'var(--warning-soft)', icon: PaperPlaneTilt },
  fulfillment:  { label: 'Fulfillment',  color: 'var(--blue-shade-40)', bg: 'var(--state-info-soft)', icon: Receipt },
  published:    { label: 'Published',    color: 'var(--blue-shade-40)', bg: 'var(--state-info-soft)', icon: Receipt },
  shipment:     { label: 'Shipment',     color: 'var(--blue-shade-20)', bg: 'var(--blue-tint-80)', icon: Receipt },
  back_ordered: { label: 'Back Order',   color: 'var(--blue-shade-20)', bg: 'var(--blue-tint-80)', icon: Clock },
  complete:     { label: 'Complete',     color: 'var(--state-success-text)', bg: 'var(--state-success-soft)', icon: CheckCircle },
  fulfilled:    { label: 'Fulfilled',    color: 'var(--state-success-text)', bg: 'var(--state-success-soft)', icon: CheckCircle },
  fulfilled: { label: 'Fulfilled', color: 'var(--state-success-text)', bg: 'var(--state-success-soft)', icon: CheckCircle },
  cancelled: { label: 'Cancelled', color: 'var(--state-error-text)', bg: 'var(--state-error-soft)', icon: X } }

const TABS = [
  { key: 'all',       label: 'All'       },
  { key: 'draft',     label: 'Drafts'    },
  { key: 'submitted', label: 'Submitted' },
  { key: 'published', label: 'Published' },
  { key: 'fulfilled', label: 'Fulfilled' },
]

function StatusBadge({ status }) {
  const meta = STATUS_META[status] || STATUS_META.draft
  const Icon = meta.icon
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: '3px 10px', borderRadius: 'var(--radius-s)',
      fontSize: 'var(--text-xs)', fontWeight: 700,
      background: meta.bg, color: meta.color }}>
      <Icon size="0.6875rem" weight="fill" />
      {meta.label}
    </span>
  )
}

function POCard({ po, totals, onPress }) {
  const matTotal = totals?.materials || 0
  const laborTotal = totals?.labor || 0
  const grandTotal = matTotal + laborTotal

  return (
    <button onClick={onPress} style={{
      display: 'flex', alignItems: 'center', gap: '0.75rem',
      padding: 'var(--space-l)', background: 'none',
      width: '100%', textAlign: 'left', borderBottom: '1px solid var(--border-default)',
      cursor: 'pointer', WebkitTapHighlightColor: 'transparent' }}>
      {/* Icon */}
      <div style={{
        width: '2.75rem', height: '2.75rem', borderRadius: 'var(--radius-l)',
        background: po.division === 'Bolt' ? 'var(--state-warning-soft)' : 'var(--state-info-soft)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
        <Receipt size="1.25rem" style={{ color: po.division === 'Bolt' ? 'var(--state-warning-text)' : 'var(--brand-primary)' }} />
      </div>

      {/* Info */}
      <div className="u-flex-1-min-0">
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-s)', marginBottom: 3, flexWrap: 'wrap' }}>
          <span className="u-text-sm-bold-primary">
            {po.so_number}
          </span>
          <StatusBadge status={po.status} />
          <span style={{
            fontSize: 'var(--text-xs)', fontWeight: 700, padding: '1px 6px',
            borderRadius: 'var(--radius-s)',
            background: po.division === 'Bolt' ? 'var(--state-warning-soft)' : 'var(--state-info-soft)',
            color: po.division === 'Bolt' ? 'var(--state-warning-text)' : 'var(--brand-primary)' }}>
            {po.division === 'Bolt' ? 'Bolt' : 'LM'}
          </span>
        </div>
        <div style={{ fontSize: 'var(--text-sm)', fontWeight: 600, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {po.customer_name}
        </div>
        <div style={{ fontSize: 'var(--text-xs)', color: 'var(--text-muted)', marginTop: 2, display: 'flex', gap: 'var(--space-s)' }}>
          {po.project_name && <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{po.project_name}</span>}
          {po.so_date && <span>· {new Date(po.so_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>}
        </div>
      </div>

      {/* Total + chevron */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-s)', flexShrink: 0 }}>
        {grandTotal > 0 && (
          <span className="u-text-sm-bold-primary">
            ${grandTotal.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
          </span>
        )}
        <CaretRight className="u-text-primary" size="0.8125rem" />
      </div>
    </button>
  )
}

export default function PurchaseOrders() {
  const navigate = useNavigate()
  const [pos, setPos] = useState([])
  const [totals, setTotals] = useState({}) // keyed by po id
  const [loading, setLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('all')
  const [search, setSearch] = useState('')
  const [divisionFilter, setDivisionFilter] = useState('all') // all | LM | Bolt

  useEffect(() => {
    Promise.all([
      db.from('sales_orders').select('*').order('created_at', { ascending: false }),
      db.from('so_line_items').select('so_id, line_type, quantity, unit_cost'),
    ]).then(([{ data: poData }, { data: lineData }]) => {
      setPos(poData || [])
      // Compute totals per SO
      const t = {}
      for (const li of lineData || []) {
        if (!t[li.so_id]) t[li.so_id] = { materials: 0, labor: 0 }
        const amt = (li.quantity || 0) * (li.unit_cost || 0)
        if (li.line_type === 'labor') t[li.so_id].labor += amt
        else t[li.so_id].materials += amt
      }
      setTotals(t)
      setLoading(false)
    })
  }, [])

  const filtered = pos.filter(po => {
    if (activeTab !== 'all' && po.status !== activeTab) return false
    if (divisionFilter !== 'all' && po.division !== divisionFilter) return false
    if (search) {
      const q = search.toLowerCase()
      return (
        po.so_number.toLowerCase().includes(q) ||
        (po.customer_name || '').toLowerCase().includes(q) ||
        (po.project_name || '').toLowerCase().includes(q) ||
        (po.job_reference || '').toLowerCase().includes(q)
      )
    }
    return true
  })

  // Counts per tab
  const counts = {}
  for (const tab of TABS) {
    counts[tab.key] = tab.key === 'all' ? pos.length : pos.filter(p => p.status === tab.key).length
  }

  // Stats
  const queuedCount = pos.filter(p => ['queued','running'].includes(p.status)).length
  const totalPublishedValue = pos
    .filter(p => ['complete','fulfilled','shipment','fulfillment'].includes(p.status))
    .reduce((s, po) => {
      const t = totals[po.id]
      return s + (t ? t.materials + t.labor : 0)
    }, 0)

  return (
    <div className="page-content fade-in">

      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 'var(--space-m)' }}>
        <button onClick={() => navigate('/sales-orders/new')}
          className="btn btn-navy"
          style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-s)' }}>
          <Plus size="0.9375rem" /> New Sales Order
        </button>
      </div>

      {/* Alert banner for submitted POs awaiting review */}
      {queuedCount > 0 && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: '0.75rem',
          padding: 'var(--space-m) var(--space-l)', background: 'var(--warning-soft)',
          borderRadius: 'var(--radius-l)', marginBottom: '1rem', cursor: 'pointer' }} onClick={() => setActiveTab('queued')}>
          <Warning size="1.125rem" weight="fill" style={{ color: 'var(--warning)', flexShrink: 0 }} />
          <div className="u-flex-1">
            <div style={{ fontSize: 'var(--text-sm)', fontWeight: 700, color: 'var(--warning-text)' }}>
              {queuedCount} Sales Order{queuedCount !== 1 ? 's' : ''} in queue
            </div>
            <div style={{ fontSize: 'var(--text-xs)', color: 'var(--warning-text)' }}>
              Tap to review and publish
            </div>
          </div>
          <CaretRight size="0.875rem" style={{ color: 'var(--warning)' }} />
        </div>
      )}

      {/* Stats strip */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--space-m)', marginBottom: 'var(--space-l)' }}>
        {[
          { label: 'Total Orders', value: pos.length },
          { label: 'In Queue', value: queuedCount, color: queuedCount > 0 ? 'var(--warning)' : undefined },
          { label: 'Published Value', value: '$' + (totalPublishedValue / 1000).toFixed(0) + 'k', color: 'var(--state-success-text)' },
        ].map(s => (
          <div key={s.label} style={{ background: 'var(--surface-base)', borderRadius: 'var(--radius-l)', padding: 'var(--space-m)', textAlign: 'center' }}>
            <div style={{ fontSize: 'var(--text-xl)', fontWeight: 800, color: s.color || 'var(--text-primary)' }}>{s.value}</div>
            <div className="u-text-xs-muted-mt-2">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 2, marginBottom: 'var(--space-m)', overflowX: 'auto', scrollbarWidth: 'none', borderBottom: '2px solid var(--border-default)', paddingBottom: 0 }}>
        {TABS.map(tab => (
          <button key={tab.key} onClick={() => setActiveTab(tab.key)}
            style={{
              flexShrink: 0, padding: '0.5rem 0.75rem',
              background: 'none', cursor: 'pointer', fontSize: 'var(--text-sm)',
              fontWeight: activeTab === tab.key ? 700 : 500,
              color: activeTab === tab.key ? 'var(--brand-primary)' : 'var(--text-muted)',
              borderBottom: activeTab === tab.key ? '2px solid var(--brand-primary)' : '2px solid transparent',
              marginBottom: -2, whiteSpace: 'nowrap' }}>
            {tab.label}
            {counts[tab.key] > 0 && (
              <span style={{ marginLeft: 6, fontSize: 'var(--text-xs)', background: activeTab === tab.key ? 'var(--brand-primary)' : 'var(--surface-hover)', color: activeTab === tab.key ? '#fff' : 'var(--text-muted)', borderRadius: 'var(--radius-l)', padding: '1px 6px', fontWeight: 700 }}>
                {counts[tab.key]}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Search + division filter */}
      <div style={{ display: 'flex', gap: 'var(--space-s)', marginBottom: 'var(--space-l)', flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <MagnifyingGlass size="0.9375rem" style={{ position: 'absolute', left: 11, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search SO#, customer, project…"
            style={{ width: '100%', paddingLeft: 34, paddingRight: search ? 34 : 12 }} />
          {search && <button onClick={() => setSearch('')} style={{ position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)', background: 'none', cursor: 'pointer', color: 'var(--text-muted)' }}><X size="0.8125rem" /></button>}
        </div>
        {['all', 'LM', 'Bolt'].map(d => (
          <button key={d} onClick={() => setDivisionFilter(d)}
            style={{
              padding: 'var(--space-xs) var(--space-m)', borderRadius: 'var(--radius-l)', fontSize: 'var(--text-xs)', fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap',
              border: `1px solid ${divisionFilter === d ? 'var(--brand-primary)' : 'var(--border-subtle)'}`,
              background: divisionFilter === d ? 'var(--brand-primary)' : 'var(--surface-hover)',
              color: divisionFilter === d ? '#fff' : 'var(--text-primary)' }}>
            {d === 'all' ? 'All Divisions' : d === 'LM' ? 'Lightning Master' : 'Bolt Lightning'}
          </button>
        ))}
      </div>

      {/* PO list */}
      {loading ? (
        <div className="u-flex-center-pad-2xl"><div className="spinner" /></div>
      ) : filtered.length === 0 ? (
        <div className="empty">
          <Receipt size="2.5rem" style={{ color: 'var(--text-muted)', marginBottom: 'var(--space-m)' }} />
          <div className="empty-title">{pos.length === 0 ? 'No sales orders yet' : 'No SOs match filters'}</div>
          <div className="empty-desc">{pos.length === 0 ? 'Create your first Sales Order to get started.' : 'Try adjusting your filters.'}</div>
          {pos.length === 0 && (
            <button className="btn btn-primary" style={{ marginTop: 'var(--space-l)' }} onClick={() => navigate('/sales-orders/new')}>
              Create First Sales Order
            </button>
          )}
        </div>
      ) : (
        <div style={{ background: 'var(--surface-base)', borderRadius: 'var(--radius-m)', overflow: 'hidden' }}>
          {filtered.map(po => (
            <POCard key={po.id} po={po} totals={totals[po.id]} onPress={() => navigate(`/sales-orders/${po.id}`)} />
          ))}
        </div>
      )}
    </div>
  )
}
