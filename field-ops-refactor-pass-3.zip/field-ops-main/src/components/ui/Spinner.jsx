/**
 * Spinner
 * Loading state. Centered by default, inline variant available.
 *
 * Props:
 *   inline  — renders inline (no centering wrapper)
 *   size    — 'sm' | 'md' (default) | 'lg'
 *   label   — optional text next to spinner
 */
export default function Spinner({ inline, size, label }) {
  const s = size === 'sm' ? 'spinner--sm' : size === 'lg' ? 'spinner--lg' : ''

  const el = (
    <div className="u-flex-center-gap-s">
      <div className={`spinner ${s}`} />
      {label && <span className="u-text-sm-muted">{label}</span>}
    </div>
  )

  if (inline) return el

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 'var(--space-2xl)' }}>
      {el}
    </div>
  )
}
